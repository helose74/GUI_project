from tkinter import *

root = Tk()
root.title("YW GUI")

btn1 = Button(root, text = "버튼1")
btn1.pack()

btn2 = Button(root, padx = 5, pady = 10, text = "버튼2")
btn2.pack()

btn3 = Button(root, padx = 10, pady = 5, text = "버튼3")
btn3.pack()

photo = PhotoImage(file = "GUI_basic/image.png")
btn4 = Button(root, image = photo)
btn4.pack()

def btncmd():
    print("버튼이 클릭되었어요")

btn5 = Button(root, text = "동작하는 버튼", command = btncmd)
btn5.pack()

root.mainloop()