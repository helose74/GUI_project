from tkinter import *

root = Tk()
root.title("YW GUI")
root.geometry("640x480+600+300" )

root.resizable(False, False)

root.mainloop()